# Reliability and simplification: paired blackbox verification

Date: 2026-10-01. All 327 cases succeeded in both runs. Every case preserved status, retrieved paths and line spans, quality metrics, and returned character count. Quality was unchanged across intent, source language, query language, and project snapshot groups. This establishes retrieval preservation, not a quality improvement.

| Suite | Cases | Quality, identical in both runs | Mean characters, identical | p50 ms, baseline → candidate |
| --- | ---: | --- | ---: | ---: |
| short_queries | 240 | Top-1 1.0000; MRR 1.0000 | 11043.41 | 41 → 41 |
| semantic_queries | 39 | relevant Top-1 0.7436; nDCG@10 0.7526 | 30410.13 | 559 → 507 |
| project_cases | 35 | primary Hit@3 0.9714; relation recall 0.9338; test recall 1.0000; distractor_head 0 | 19244.43 | 68 → 70 |
| swe_explore development | 13 | edit Top-1 0.4615; core Top-1 0.7692; nDCG@100 0.6237 | 24952.62 | 2092 → 1888 |

This was one sequential pair using remote embedding. Timing changes are observations, not proof of a stable code-induced speedup. Existing limitations remain: project cases still classify 19 cases as redundant, 3 as relation_missing, and 1 as exact_miss; SWE edit Top-1 remains 0.4615.

## Controls and validity

- Used the [official oce-client v0.2.0 release](https://github.com/JasonEX/oce-client/releases/tag/v0.2.0), not a local build. Archive SHA256: `e294a2f021ba5a31d3c2fdaca20c2aad49f2e1c93309d1afe1d47300fdcb7b95`. Binary SHA256: `ec7983848c3515e30774517f94c629289504cca43f974113a18b6b247545eb61`.
- Original manifests, case IDs, and truth were unchanged. Official `ensure_comparable` and all four official compare commands passed. Product runners used the release client and stable HTTP APIs; they did not import server `oce`, read databases, or reproduce server routing.
- Both runs exclusively reused the same physical Milvus index in sequence. SQL and client states were independent copies. Candidate SQL was copied from completed baseline SQL, then migrated. Original SQL and client states were not written; their latest modification times still predate this run.
- Client/HTTP preflight covered 26 snapshot entries and 9676 distinct blobs: unknown=0 and nonindexed=0 in both runs. Every synchronization reported `uploaded_blobs=0`.
- Compatible profile fingerprint: `ca1a70df0d12599cb305aede959e7bb99c46991fe0472faa7e71d50cb4862b1c`; Qwen3-Embedding-4B, 1024 dimensions. Dense entities=346265 and path entities=57751 before scoring and at candidate completion; both stores were available.
- Worker, rerank, LLM rerank, query rewrite, and query vector cache were disabled. Both runs recorded 376 embedding calls. Missing endpoint usage is recorded as zero tokens and does not mean no tokens were consumed.
- Baseline scoring: `2026-10-01T15:57:41.563887+00:00` to `16:00:19.329614+00:00`; candidate: `16:20:21.057298+00:00` to `16:22:48.841718+00:00`. Suite order: short, semantic, project, SWE. Other tests and frozen dumps finished before candidate scoring.
- Initial baseline gRPC proxy interference was resolved by a literal loopback exclusion and restart before scoring. Candidate dense warmup timeout and a local GOAWAY occurred before scoring; index/API preflight subsequently passed and scored cases had no errors.
- All processes started for this benchmark are now stopped; port 18986 is free and neither SQL copy has a WAL file.

## Source boundary and limits

Recorded scoring snapshots: baseline `1cc20b6cebf4e4c98512549ddf6c270bdd3f19f8f7c318e99c425a3d38355eee` (179 Python files), candidate `d8a90c90b542b7a930ad0ac5b92208d718ea29dcb75166fea75eb75bb547b325` (182). Baseline source: `/tmp/oce-audit-fix-jsyaidz2/baseline/src`.

Two compatibility fixes landed after scoring: combined dotenv parsing in `cli.py` and removal of the new domain path-length check to allow old SQLite rows in `domain/blob/blob.py`. Dedicated regressions cover them separately. The final whole source tree was not rerun through these four suites.

Blackbox case records contain paths and line spans, not bytewise response text or retrieval scores. The independent frozen dump supplies that evidence. Worker-disabled personal mode does not validate Redis/background faults; targeted fault tests supply that evidence. Final unit, static, packaging, and frozen-dump results belong in the main review report.

## Inspectable artifacts

Directory: `/home/yuqian/.cache/oce/audit-paired-20261001-hymbn8ch`.

- Eight `baseline-*.json` / `candidate-*.json` raw suite reports.
- Four `compare-*.md` official comparisons.
- `paired-summary.json`: summary, grouped, and per-case differences, all empty.
- `reliability-simplification-2026-10-01.json`: machine-readable evidence, limits, and artifact SHA256 hashes.
- `provenance.json`, `*-preflight.json`, `*-timing.json`, and `candidate-final-index-stats.json`: client, source, preflight, timing, and API evidence.

The archive contains only these reports and public provenance; it excludes databases, full logs, and credentials. Temporary credentials were loaded into processes from the existing external environment file.
