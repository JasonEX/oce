| Variant | OK | Edit Top-1 | Core Top-1 | Edit file R@10 | Edit region R@10 | Core file R@10 | Core region R@10 | SWE line R | SWE nDCG@100 | SWE nDCG@500 | SWE first hit | SWE efficiency | Latency ms | p50 ms | p95 ms | Chars |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| baseline | 13/13 | 46.2% | 76.9% | 80.8% | 38.5% | 66.5% | 57.6% | 6.2% | 62.4% | 75.6% | 88.1% | 29.2% | 2301 | 2092 | 3772 | 24953 |
| candidate | 13/13 | 46.2% | 76.9% | 80.8% | 38.5% | 66.5% | 57.6% | 6.2% | 62.4% | 75.6% | 88.1% | 29.2% | 1992 | 1888 | 2877 | 24953 |
